package view;

public class Validation extends Exception{
	public Validation(String s)
	{
		super(s);
	}
}
