package throwException;

public class ValidDateException extends Exception{
	public ValidDateException(String str)
	{
		super(str);
	}
}
